import React, { useState } from 'react';
import type { EdgeTask } from '../types/simulation';

interface ExplainabilityLogProps {
  tasks: EdgeTask[];
}

export const ExplainabilityLog: React.FC<ExplainabilityLogProps> = ({ tasks }) => {
  // Find all tasks that have been assigned by PPO
  const scheduledTasks = tasks.filter((t) => t.assignedServerId && t.explanation);

  const [expandedTaskId, setExpandedTaskId] = useState<string | null>(null);

  if (scheduledTasks.length === 0) return null;

  const toggleExpand = (id: string) => {
    setExpandedTaskId(expandedTaskId === id ? null : id);
  };

  return (
    <div className="panel" style={{ marginTop: '16px' }}>
      <div className="panel-title">
        <span>PPO Decision Rationale Log</span>
        <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>Simple Academic Rationale</span>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        {scheduledTasks.map((t) => {
          const isExpanded = expandedTaskId === t.id || scheduledTasks.length === 1;
          const exp = t.explanation!;

          return (
            <div
              key={t.id}
              style={{
                background: 'var(--bg-subpanel)',
                border: '1px solid var(--border-color)',
                borderRadius: '4px',
                padding: '8px 10px',
                fontSize: '0.8rem'
              }}
            >
              {/* Header clickable line */}
              <div
                onClick={() => toggleExpand(t.id)}
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  cursor: 'pointer',
                  fontWeight: 600
                }}
              >
                <span className="font-mono" style={{ color: 'var(--accent-blue)' }}>
                  Why Server {t.assignedServerId} for {t.id}?
                </span>
                <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                  {isExpanded ? '▼ Hide' : '► View'}
                </span>
              </div>

              {/* Expanded details */}
              {isExpanded && (
                <div style={{ marginTop: '8px', paddingTop: '6px', borderTop: '1px solid var(--border-color)', display: 'flex', flexDirection: 'column', gap: '4px', fontSize: '0.76rem', color: 'var(--text-muted)' }}>
                  <div>• <strong>Network Delay:</strong> {exp.delay}</div>
                  <div>• <strong>Queue Status:</strong> {exp.queue}</div>
                  <div>• <strong>CPU Availability:</strong> {exp.cpu}</div>
                  <div>• <strong>Task SLA:</strong> {exp.priority}</div>
                  <div style={{ marginTop: '4px', color: 'var(--text-main)', fontStyle: 'italic' }}>
                    "{exp.summary}"
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
